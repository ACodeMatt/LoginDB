
function signup(){
    document.getElementById("signup").style.display="initial"
    document.getElementById("login").style.display="none"
}
function login(){
    document.getElementById("login").style.display="initial"
    document.getElementById("signup").style.display="none"
    document.getElementById("recoveryDiv").style.display="none"
}  
function recovery(){
    document.getElementById("login").style.display="none"
    document.getElementById("recoveryDiv").style.display="initial"
}