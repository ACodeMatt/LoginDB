<html>
    <body>
        <?php
            $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $username = $_POST['username'];
            $password = $_POST['password'];
            function generate_string($input, $strength = 16) {
                $input_length = strlen($input);
                $random_string = '';
                for($i = 0; $i < $strength; $i++) {
                    $random_character = $input[mt_rand(0, $input_length - 1)];
                    $random_string .= $random_character;
                }
             
                return $random_string;
            }
            $securekey = generate_string($permitted_chars, 10);

            $con = new mysqli("localhost","root","","users") or die ("Non sono riuscito a connettermi");
            mysqli_select_db($con, 'users');

            $sql = "INSERT INTO `utenti` (`UserID`, `Username`, `Password`, `SecureKey`) VALUES  ('NULL', 
            '$username', '$password', '$securekey'); ";
            if($con -> query($sql) === TRUE){
                echo "Ottimo ricorda la tua chiave di sicurezza -> ".$securekey." e' l'unico modo di recuperare la tua password.";
            }else{
                echo "errore";
            }
            $con->close();

            
        ?>
    </body>
</html>