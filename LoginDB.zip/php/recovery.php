<html>
    <body>
            <?php
            $securekey = $_POST['securekey'];
            
            
            $conn = mysqli_connect('localhost', 'root', '', 'users');
            
            if (!$conn) {
              die("Connessione fallita: " . mysqli_connect_error());
            }
            
            $sql = "SELECT UserID, Username, Password FROM utenti WHERE SecureKey='$securekey'";
            $result = mysqli_query($conn, $sql);
            
            if (mysqli_num_rows($result) > 0) {
             
              while($row = mysqli_fetch_assoc($result)) {
                echo "UserID: " . $row["UserID"]. "<br>" ."Username: " . $row["Username"]. "<br>". "Password: " . $row["Password"]. "<br>";
              }
            } else {
              echo "Chaive non valida o utente non registrato.";
            }
            
            mysqli_close($conn);
            ?>
    </body>
</html>
