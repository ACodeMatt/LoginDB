
<html>
    <body>

        <?php
            $user = $_POST['username'];
            $pass = $_POST['password'];
            $conn = mysqli_connect('localhost', 'root', '', 'users');
            
            if (!$conn) {
              die("Connessione fallita: " . mysqli_connect_error());
            }
            
            $sql = "SELECT UserID FROM utenti WHERE Username='$user' AND Password='$pass'";
            $result = mysqli_query($conn, $sql);
            
            if (mysqli_num_rows($result) > 0) {
                
                header("location: ../page.php");
                
            }else{
                echo '<script>alert("Credenziali errate, ritorno al login...")</script>';
                
                header('Refresh: 0.5; URL=../index.html');
            }
        ?>


    </body>
</html>